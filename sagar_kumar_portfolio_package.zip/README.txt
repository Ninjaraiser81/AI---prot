# Sagar Kumar - Portfolio Package

This archive contains everything you need to run and deploy your personal portfolio website:

1. `index.html` - The complete web code.
2. `profile.png` - Your professional portrait photo (rename your photo file to `profile.png` if replacing).

## How to deploy:
- **Netlify Drop:** Drag and drop this ZIP file directly to https://drop.netlify.com
- **GitHub Pages:** Upload `index.html` and `profile.png` to your GitHub repo (`Ninjaraiser81`) and activate Pages in Settings.
